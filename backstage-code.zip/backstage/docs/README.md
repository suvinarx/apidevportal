# Documentation Assets

This folder contains documentation files, screenshots, and diagrams for the API Hub project.

## Images

Place README screenshots and portal diagrams in:

```text
docs/images/
