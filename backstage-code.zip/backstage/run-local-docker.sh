#!/bin/bash
set -e

echo "Building and starting local API Hub Docker environment..."

docker compose -f docker-compose.local.yml down -v --remove-orphans
docker compose -f docker-compose.local.yml up -d --build --force-recreate

echo ""
echo "API Hub is starting."
echo "Open: http://localhost:7007"
echo ""
echo "To view logs:"
echo "docker compose -f docker-compose.local.yml logs -f backstage"
