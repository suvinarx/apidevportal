# API Hub

API Hub is a Backstage-based developer portal for discovering, documenting, and managing APIs in one central place.

This project is customized for the Girl Scouts API ecosystem and supports local Docker-based development.

---

## Overview

API Hub provides a centralized portal where teams can:

- Browse registered APIs
- View API metadata and definitions
- Search API catalog entries
- Manage API onboarding workflows
- Run the portal locally using Docker
- Connect to PostgreSQL for Backstage catalog data

---

## Screenshots

Add screenshots to `docs/images/` using the filenames below.

### Home Page

![Home Page](docs/images/home-page.png)

### API Catalog

![API Catalog](docs/images/api-catalog.png)

### API Details Page

![API Details](docs/images/api-details.png)

---

## Project Structure

```text
api-hub/
├── app-config.yaml
├── app-config.production.yaml
├── docker-compose.local.yml
├── Dockerfile.local
├── run-local-docker.sh
├── packages/
│   ├── app/
│   └── backend/
└── examples/
```

---

## Prerequisites

Before running locally, make sure you have:

- Docker Desktop installed and running
- Git installed
- Access to the required Docker base image
- Port `7007` available on your machine

---

## Run Locally with Docker

From the project root:

```bash
./run-local-docker.sh
```

The script will:

1. Build the local Docker image
2. Start PostgreSQL
3. Start the Backstage API Hub container
4. Expose the portal on port `7007`

Open the portal:

```text
http://localhost:7007
```

---

## View Logs

```bash
docker compose -f docker-compose.local.yml logs -f backstage
```

PostgreSQL logs:

```bash
docker compose -f docker-compose.local.yml logs -f postgres
```

---

## Stop Local Environment

Stop containers but keep the database volume:

```bash
docker compose -f docker-compose.local.yml down
```

Stop containers and remove the local database volume:

```bash
docker compose -f docker-compose.local.yml down -v --remove-orphans
```

---

## Rebuild Fresh

Use this when you want to rebuild the local Docker image from scratch:

```bash
docker compose -f docker-compose.local.yml down -v --remove-orphans
docker rmi api-hub:local 2>/dev/null || true
./run-local-docker.sh
```

---

## Docker Files

### `Dockerfile.local`

Used to build the local API Hub image.

### `docker-compose.local.yml`

Starts the local API Hub stack:

- `postgres`
- `backstage`

### `run-local-docker.sh`

Convenience script to build and run the local Docker environment.

---

## Optional GitHub Token

If GitHub integration is enabled in the Backstage configuration, export a GitHub token before starting:

```bash
export GITHUB_TOKEN=your_github_token_here
./run-local-docker.sh
```

---

## Development Workflow

Create or switch to the `develop` branch:

```bash
git checkout develop
```

Check status:

```bash
git status
```

Commit changes:

```bash
git add .
git commit -m "Describe your change"
git push origin develop
```

---

## Image Upload Placeholder

Create this folder for screenshots and diagrams:

```bash
mkdir -p docs/images
```

Recommended image locations:

```text
docs/images/home-page.png
docs/images/api-catalog.png
docs/images/api-details.png
docs/images/local-docker-run.png
```

Then reference images in this README using:

```md
![Description](docs/images/image-name.png)
```

---

## Notes

This repository contains the API Hub application files used to run the Backstage-based portal locally and in containerized environments.

For production deployment, use the approved production Docker image and environment-specific configuration.
